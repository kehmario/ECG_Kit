#include <atmel_start.h>

struct io_descriptor *io;

volatile bool conversion = false;
uint8_t adc_result;

void uart_init(void)
{
	usart_sync_get_io_descriptor(&USART_0, &io);
	usart_sync_enable(&USART_0);
}

static void adc_cb(const struct adc_async_descriptor *const descr, const uint8_t channel)
{
	conversion = true;
}
void adc_init(void)
{
	adc_async_register_callback(&ADC_0, 0, ADC_ASYNC_CONVERT_CB,adc_cb);
	adc_async_enable_channel(&ADC_0, 0);
	adc_async_start_conversion(&ADC_0);
}
int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	uart_init();
	io_write(io, (uint8_t *)"UART!!", 5);
	adc_init();
	io_write(io, (uint8_t *)"ADC!!", 5);
	adc_async_start_conversion(&ADC_0);
	io_write(io, (uint8_t *)"Hello World!", 12);
	/* Replace with your application code */
	while (1) {
		delay_ms(100);
		adc_async_start_conversion(&ADC_0);
		while(!conversion){};
		adc_async_read_channel(&ADC_0, 0, &adc_result, 1);
		io_write(io, (uint8_t *)&adc_result, 1);
	}
}